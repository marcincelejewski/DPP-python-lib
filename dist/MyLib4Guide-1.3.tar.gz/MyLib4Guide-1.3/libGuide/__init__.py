import libGuide.app
import libGuide.guide

print("Inicializacja")
