from setuptools import setup, find_packages
setup(
    name='python-git-lib',
    version='1.1',
    author='Marcin Celejewski',
    author_email='marcin.celejewski18@gmail.com',
    url='https://github.com/marcincelejewski/DPP-python-lib.git',
    packages=find_packages()   
)
