from library.app import App

print("Inicializacja")
