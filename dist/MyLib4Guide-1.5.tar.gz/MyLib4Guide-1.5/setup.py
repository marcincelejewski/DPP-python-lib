from setuptools import setup, find_packages
setup(
    name='MyLib4Guide',
    version='1.5',
    author='Marcin Celejewski',
    author_email='marcin.celejewski18@gmail.com',
    url='https://github.com/marcincelejewski/DPP-python-lib.git',
    packages=find_packages()   
)
