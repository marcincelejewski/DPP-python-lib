import libGuide.app

print("Wczytano biblioteki")
