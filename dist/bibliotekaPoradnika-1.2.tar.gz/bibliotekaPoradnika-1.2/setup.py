from setuptools import setup, find_packages
setup(
    name='bibliotekaPoradnika',
    version='1.2',
    author='Marcin Celejewski',
    author_email='marcin.celejewski18@gmail.com',
    url='https://github.com/marcincelejewski/DPP-python-lib.git',
    packages=find_packages()   
)
